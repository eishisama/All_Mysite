# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end


Refile.secret_key = 'feab2bc2894d5ff36c3c721d8f7c0b1716362d25b433087e34851fa6ee92171d22880d2f14715069939a5b462bfb4ba40dbe5b31f6795a3027062672db4af560'