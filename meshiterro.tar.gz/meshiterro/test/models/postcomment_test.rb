require 'test_helper'

class PostcommentTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
