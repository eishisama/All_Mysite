# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = 'a06f1810e3885e42bcb6cfbaf43d4b8fc273ef8094d4a33807ca4c11d94e1aed9f86e11d08feaf3420488fd7e40224ea3cb3707e768d06139a6baa6d3d662784'

