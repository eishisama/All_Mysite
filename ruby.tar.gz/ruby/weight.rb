name="A"
weight=50
puts "#{name}さんの体重は#{weight}kgです。"