tall={:太郎=>185, :二郎=>170, :花子=>150}
puts tall[:太郎]
puts tall[:花子]