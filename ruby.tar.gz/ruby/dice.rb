dice=0

while dice!=6 do
  dice=rand(1..10)
  puts dice
end