subject=["国語", "数学", "体育", "英語", "プログラミング"]
puts subject[4]