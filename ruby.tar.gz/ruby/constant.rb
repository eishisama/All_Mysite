Pi = 3.14
puts Pi