def greeting(name)
  return "Hello, #{name}!"
  "Good morning, #{name}!"
end

puts greeting("John")