name="吉本栄史"
puts name