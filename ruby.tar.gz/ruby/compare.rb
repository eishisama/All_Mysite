total=600
if total<500
  puts "合計は500未満です"
end

