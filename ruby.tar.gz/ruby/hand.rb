hand = "グー"
if hand == "グー"
  puts "出したてはグーです"
end

if hand != "チョキ"
  puts "出したては猪木ではありません"
end

if (hand == "グー")||(hand == "パー")
  puts "出したてはグーまたはパーです"
end