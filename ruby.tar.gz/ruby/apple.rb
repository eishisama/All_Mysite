apple="Okinawa"

if apple=="Yamanashi"
  puts "このリンゴは山梨県さんです"
elsif apple=="Okinawa"
  puts "このリンゴは沖縄県産です"
else
  puts "このリンゴは山梨県産でも沖縄県産でもありません。"
end