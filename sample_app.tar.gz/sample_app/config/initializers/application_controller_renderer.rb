# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '27edacc59026ee4bda0301190cac66399f6c631f3d343472d228dcde49e8c50a424ab4468147d62d48f8b3f9296de2333c13218daad5cb5a75242c269a5e095e'
